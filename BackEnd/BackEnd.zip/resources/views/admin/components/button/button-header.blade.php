<a href="{{ route($urlbase.'create') }}" class="btn btn-danger me-3">Thêm</a>
<a href="{{ route($urlbase.'index') }}" class="btn btn-success">Danh sách</a>
