<?php

const FIELD_IMAGE =["cate_image"];





const FIELD_DESC =["description"];

const BUTTON_HEADER_ADMIN_LINK = 'admin.components.button.button-header';

const IMAGES_FIELD ="image";

const DESC_FIELD ="description";
/*
 * Huy Đạt writter
 * Khai báo hằng số để bắt giá trị
 * */
