<?php $__env->startSection('title','hahaha'); ?>
<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugins/datatables/datatables.min.css')); ?>">

<?php $__env->stopPush(); ?>
<?php $__env->startSection('heading','hihihi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Default Datatable</h4>
                    <p class="card-text">
                        This is the most basic example of the datatables with zero configuration. Use the <code>.datatable</code> class to initialize datatables.
                    </p>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="datatable table table-stripped">

                            <thead>
                            <?php $__currentLoopData = $colums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colum=>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($name); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td>Hành động</td>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $__currentLoopData = $colums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colum=>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <td>
                                            <?php if(in_array($colum, FIELD_IMAGE)): ?>
                                                <img src="<?php echo e(asset($item->$colum)?? '123'); ?>" width="50px" alt="">
                                            <?php else: ?>
                                                <?php echo e($item->$colum); ?>

                                            <?php endif; ?>


                                        </td>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <button class="btn btn-warning">

                                            <a style="color: white" href="<?php echo e(route($urlbase . 'show', $item)); ?>">Xem</a>
                                        </button>

                                        <button class="btn btn-success">
                                            <a style="color: white" href="<?php echo e(route($urlbase . 'edit', $item)); ?>">Sửa</a>
                                        </button>

                                        <form action="<?php echo e(route($urlbase . 'destroy', $item)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button class="btn btn-danger"
                                                    onclick=" return confirm('Bạn có chắc muốn xóa không?  Hành động này của bạn có thể dẫn đến mất dữ liệu')"
                                                    type="submit">Xóa
                                            </button>
                                        </form>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('backend/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/datatables/datatables.min.js')); ?>"></script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BeePets\BackEnd\resources\views/admin/serviceCategories/index.blade.php ENDPATH**/ ?>