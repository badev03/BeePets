<a href="{{ route($urlbase.'create') }}" class="btn btn-sm bg-danger-light me-3 d-flex align-items-center">Thêm</a>
<a href="{{ route($urlbase.'index') }}" class="btn btn-sm bg-success-light d-flex align-items-center">Danh sách</a>
