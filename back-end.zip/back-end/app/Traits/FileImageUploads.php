<?php

namespace App\Traits;

trait FileImageUploads {

}
