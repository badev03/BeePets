<?php

return [

    'authentication_key' => '{AUTHENTICATION_KEY}'

];
